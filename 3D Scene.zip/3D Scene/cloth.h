#pragma once
#include <glad/glad.h>
#include <vector>

using namespace std; // Standard namespace

class Cloth
{
public:
	static vector<GLfloat>* drawCloth();
};

#pragma once
#include <glad/glad.h>
#include <vector>

using namespace std; // Standard namespace

class TallPlant
{
public:
	static vector<GLfloat>* drawTallPlant();
};

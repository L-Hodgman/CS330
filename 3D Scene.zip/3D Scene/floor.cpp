#define _USE_MATH_DEFINES // for C++
#include <cmath>

#include "floor.h"

using namespace std; // Standard namespace


vector<GLfloat>* Floor::drawFloor()
{
    vector<GLfloat>* vec = new vector<GLfloat>{
         // Floor
          3.0f, -1.0f, 5.0f,  0.0f, 1.0f, 0.0f,   1.0f, 0.0f,
         -2.0f, -1.0f, 5.0f,  0.0f, 1.0f, 0.0f,   0.0f, 0.0f,
         -2.0f, -1.0f, 0.2f,  0.0f, 1.0f, 0.0f,   0.0f, 1.0f,
          3.0f, -1.0f, 5.0f,  0.0f, 1.0f, 0.0f,   1.0f, 0.0f,
          3.0f, -1.0f, 0.2f,  0.0f, 1.0f, 0.0f,   1.0f, 1.0f,
         -2.0f, -1.0f, 0.2f,  0.0f, 1.0f, 0.0f,   0.0f, 1.0f,

    };
    return vec;
}
#pragma once
#include <glad/glad.h>
#include <vector>

using namespace std; // Standard namespace

class Walls
{
public:
	static vector<GLfloat>* drawWalls();
};

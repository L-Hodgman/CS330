#pragma once
#include <glad/glad.h>
#include <vector>

using namespace std; // Standard namespace

class Ceiling
{
public:
	static vector<GLfloat>* drawCeiling();
};

#define _USE_MATH_DEFINES // for C++
#include <cmath>

#include "ceiling.h"

using namespace std; // Standard namespace


vector<GLfloat>* Ceiling::drawCeiling()
{
    vector<GLfloat>* vec = new vector<GLfloat>{

         // Ceiling
          3.0f, 3.0f, 5.0f,  0.0f, -1.0f, 0.0f,   1.0f, 1.0f,
         -2.0f, 3.0f, 5.0f,  0.0f, -1.0f, 0.0f,   0.0f, 1.0f,
         -2.0f, 3.0f, 0.2f,  0.0f, -1.0f, 0.0f,   0.0f, 0.0f,
          3.0f, 3.0f, 5.0f,  0.0f, -1.0f, 0.0f,   1.0f, 1.0f,
          3.0f, 3.0f, 0.2f,  0.0f, -1.0f, 0.0f,   1.0f, 0.0f,
         -2.0f, 3.0f, 0.2f,  0.0f, -1.0f, 0.0f,   0.0f, 0.0f,
    };
    return vec;
}
#pragma once
#include <glad/glad.h>
#include <vector>

using namespace std; // Standard namespace

class Floor
{
public:
	static vector<GLfloat>* drawFloor();
};

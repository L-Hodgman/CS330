#pragma once
#include <glad/glad.h>
#include <vector>

using namespace std; // Standard namespace

class Drawers
{
public:
	static vector<GLfloat>* drawDrawers();
};

#define _USE_MATH_DEFINES // for C++
#include <cmath>

#include "drawer_border.h"

using namespace std; // Standard namespace


vector<GLfloat>* DrawerBorder::drawDrawerBorder()
{
    vector<GLfloat>* vec = new vector<GLfloat>{
        // Vertex Positions   //Normals              // Texture Coordinates
        2.0f,  0.8f,  1.0f,    1.0f,  0.0f,  0.0f,    0.0f, 1.0f,
        2.0f, -0.99f, 1.0f,    1.0f,  0.0f,  0.0f,    0.0f, 0.0f,
        2.0f, -0.99f, 0.3f,    1.0f,  0.0f,  0.0f,    1.0f, 0.0f,
        2.0f,  0.8f,  1.0f,    1.0f,  0.0f,  0.0f,    0.0f, 1.0f,
        2.0f,  0.8f,  0.3f,    1.0f,  0.0f,  0.0f,    1.0f, 1.0f,
        2.0f, -0.99f, 0.3f,    1.0f,  0.0f,  0.0f,    1.0f, 0.0f,
        2.0f,  0.8f,  0.3f,    0.0f,  0.0f,  1.0f,    1.0f, 1.0f,
        2.0f, -0.99f, 0.3f,    0.0f,  0.0f,  1.0f,    1.0f, 0.0f,
        1.1f, -0.99f, 0.3f,    0.0f,  0.0f,  1.0f,    0.0f, 0.0f,
        2.0f,  0.8f,  0.3f,    0.0f,  0.0f,  1.0f,    1.0f, 1.0f,
        1.1f,  0.8f,  0.3f,    0.0f,  0.0f,  1.0f,    0.0f, 1.0f,
        1.1f, -0.99f, 0.3f,    0.0f,  0.0f,  1.0f,    0.0f, 0.0f,
        1.1f, -0.99f, 1.0f,   -1.0f,  0.0f,  0.0f,    0.0f, 0.0f,
        1.1f,  0.8f,  0.3f,   -1.0f,  0.0f,  0.0f,    1.0f, 1.0f,
        1.1f, -0.99f, 0.3f,   -1.0f,  0.0f,  0.0f,    1.0f, 0.0f,
        1.1f,  0.8f,  1.0f,   -1.0f,  0.0f,  0.0f,    0.0f, 1.0f,
        1.1f, -0.99f, 1.0f,   -1.0f,  0.0f,  0.0f,    0.0f, 0.0f,
        1.1f,  0.8f,  0.3f,   -1.0f,  0.0f,  0.0f,    1.0f, 1.0f,
        2.0f, -0.99f, 1.0f,    0.0f, -1.0f,  0.0f,    1.0f, 0.0f,
        2.0f, -0.99f, 0.3f,    0.0f, -1.0f,  0.0f,    1.0f, 1.0f,
        1.1f, -0.99f, 1.0f,    0.0f, -1.0f,  0.0f,    0.0f, 0.0f,
        2.0f, -0.99f, 0.3f,    0.0f, -1.0f,  0.0f,    1.0f, 1.0f,
        1.1f, -0.99f, 1.0f,    0.0f, -1.0f,  0.0f,    0.0f, 0.0f,
        1.1f, -0.99f, 0.3f,    0.0f, -1.0f,  0.0f,    0.0f, 1.0f,
        2.0f,  0.8f,  1.0f,    0.0f,  0.0f,  1.0f,    1.0f, 1.0f,
        2.0f, -0.99f, 1.0f,    0.0f,  0.0f,  1.0f,    1.0f, 0.0f,
        1.1f, -0.99f, 1.0f,    0.0f,  0.0f,  1.0f,    0.0f, 0.0f,
        2.0f,  0.8f,  1.0f,    0.0f,  0.0f,  1.0f,    1.0f, 1.0f,
        1.1f,  0.8f,  1.0f,    0.0f,  0.0f,  1.0f,    0.0f, 1.0f,
        1.1f, -0.99f, 1.0f,    0.0f,  0.0f,  1.0f,    0.0f, 0.0f,
    };
    return vec;
}
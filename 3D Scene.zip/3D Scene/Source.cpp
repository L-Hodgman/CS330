#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"
#include "camera.h"

// Room incudes
#include "ceiling.h"
#include "floor.h"
#include "walls.h"
#include "window.h"
#include "cloth.h"
#include "tall_plant.h"
#include "short_plant.h"

// Table includes
#include "table_top.h"
#include "table_legs.h"
#include "drawers.h"
#include "drawer_handles.h"
#include "drawer_border.h"

// Shape includes
#include "sphere.h"
#include "cylinder.h"

#include <iostream>

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void switchPerspective();
unsigned int loadTexture(const char* path);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// camera
Camera camera(glm::vec3(0.0f, 0.0f, 7.0f));
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
glm::mat4 _Projection;
bool firstMouse = true;

// timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

// lighting
glm::vec3 lightPos(1.2f, 1.0f, 2.0f);

// System starts in perspective view
bool perspectiveMode = true; 

int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "LearnOpenGL", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	// build and compile our shader zprogram
	// ------------------------------------
	Shader lightingShader("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
	Shader lightSphereShader("shaderfiles/6.light_cube.vs", "shaderfiles/6.light_cube.fs");

	// Pull in the object vertices from headers
	// Floor Vertices
	float floorVerts[5000];
	// Retrieve floor.h vector
	vector<float>* floorVec = Floor::drawFloor();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < floorVec->size(); i++)
	{
		floorVerts[i] = floorVec->at(i);
	}
	delete(floorVec);

	// Ceiling Vertices
	float ceilingVerts[5000];
	// Retrieve ceiling.h vector
	vector<float>* ceilingVec = Ceiling::drawCeiling();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < ceilingVec->size(); i++)
	{
		ceilingVerts[i] = ceilingVec->at(i);
	}
	delete(ceilingVec);

	// Walls Vertices
	float wallsVerts[5000];
	// Retrieve walls.h vector
	vector<float>* wallsVec = Walls::drawWalls();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < wallsVec->size(); i++)
	{
		wallsVerts[i] = wallsVec->at(i);
	}
	delete(wallsVec);

	// Window Vertices
	float windowVerts[5000];
	// Retrieve window.h vector
	vector<float>* windowVec = Window::drawWindow();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < windowVec->size(); i++)
	{
		windowVerts[i] = windowVec->at(i);
	}
	delete(windowVec);

	// Table Top Vertices
	float tableTopVerts[5000];
	// Retrieve table_top.h vector
	vector<float>* tableTopVec = TableTop::drawTableTop();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < tableTopVec->size(); i++)
	{
		tableTopVerts[i] = tableTopVec->at(i);
	}
	delete(tableTopVec);

	// Table Legs Vertices
	float tableLegsVerts[5000];
	// Retrieve table_legs.h vector
	vector<float>* tableLegsVec = TableLegs::drawTableLegs();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < tableLegsVec->size(); i++)
	{
		tableLegsVerts[i] = tableLegsVec->at(i);
	}
	delete(tableLegsVec);

	// Drawer Border Vertices
	float drawerBorderVerts[5000];
	// Retrieve drawer_border.h vector
	vector<float>* drawerBorderVec = DrawerBorder::drawDrawerBorder();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < drawerBorderVec->size(); i++)
	{
		drawerBorderVerts[i] = drawerBorderVec->at(i);
	}
	delete(drawerBorderVec);

	// Drawer Vertices
	float drawersVerts[5000];
	// Retrieve drawer.h vector
	vector<float>* drawersVec = Drawers::drawDrawers();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < drawersVec->size(); i++)
	{
		drawersVerts[i] = drawersVec->at(i);
	}
	delete(drawersVec);

	// Drawer Handles Vertices
	float drawerHandlesVerts[5000];
	// Retrieve drawer_handle.h vector
	vector<float>* drawerHandlesVec = DrawerHandles::drawDrawerHandles();

	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < drawerHandlesVec->size(); i++)
	{
		drawerHandlesVerts[i] = drawerHandlesVec->at(i);
	}
	delete(drawerHandlesVec);

	// Cloth Vertices
	float clothVerts[5000];
	// Retrieve cloth.h vector
	vector<float>* clothVec = Cloth::drawCloth();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < clothVec->size(); i++)
	{
		clothVerts[i] = clothVec->at(i);
	}
	delete(clothVec);

	// Tall Plant Vertices
	float tallPlantVerts[5000];
	// Retrieve plant.h vector
	vector<float>* tallPlantVec = TallPlant::drawTallPlant();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < tallPlantVec->size(); i++)
	{
		tallPlantVerts[i] = tallPlantVec->at(i);
	}
	delete(tallPlantVec);

	// Short Plant Vertices
	float shortPlantVerts[5000];
	// Retrieve plant.h vector
	vector<float>* shortPlantVec = ShortPlant::drawShortPlant();
	// Add vectors into verts, then delete them
	for (unsigned int i = 0; i < shortPlantVec->size(); i++)
	{
		shortPlantVerts[i] = shortPlantVec->at(i);
	}
	delete(shortPlantVec);


	// position of objects whose real positions are indicated in their vertices
	glm::vec3 roomPosition[] = {
		glm::vec3(0.0f, 0.0f, 0.0f),
	};
	// position of the plant pot cylinders
	glm::vec3 plantPotPositions[] = {
		glm::vec3(0.3f, 1.01f, 0.5f), // Tall
		glm::vec3(1.3f, 1.01f, 0.5f), // Tall
		glm::vec3(1.0f, 0.96f, 0.8f), // Short
		glm::vec3(0.1f, 0.96f, 0.8f), // Short
	};
	// position of the plants
	glm::vec3 plantPositions[] = {
		glm::vec3(0.3f,    1.0f,   0.5f),   // Tall
		glm::vec3(1.3f,    1.0f,   0.5f),   // Tall
		glm::vec3(0.775f,  1.037f, 0.55f),  // Short
		glm::vec3(-0.125f, 1.037f, 0.55f),  // Short
	};
	// position of the pumpkin sphere
	glm::vec3 pumpkinPosition[] = {
		glm::vec3(0.56f, 1.09f, 0.71f),
	};
	// Position of the pumpkin stem cylinder
	glm::vec3 pumpkinStemPosition[] = {
		glm::vec3(0.56f, 1.32f, 0.71f),
	};
	// Positions of the point light spheres
	glm::vec3 pointLightPositions[] = {
		glm::vec3(0.5f, 3.0f,  3.0f),
		glm::vec3(3.0f, 4.0f, -5.0f),
	};
	// Color of the lights
	glm::vec3 pointLightColors[] = {
		glm::vec3(1.0f, 1.0f, 1.0f), // White
		glm::vec3(3.0f, 2.0f, 1.0f), // Gold-ish 
	};


	////// Configure the Light VAO, VBO, and IBO //////
	Sphere light(1.5f, 20, 30, true);    // Radius, Sectors, Stacks, Smooth Shading bool
	unsigned int lightVBO, lightVAO, lightIBO;
	glGenBuffers(1, &lightVBO);
	glBindBuffer(GL_ARRAY_BUFFER, lightVBO);
	glBufferData(GL_ARRAY_BUFFER, light.getInterleavedVertexSize(), light.getInterleavedVertices(), GL_STATIC_DRAW);

	glGenBuffers(1, &lightIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, lightIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, lightIBO); glBufferData(GL_ELEMENT_ARRAY_BUFFER, light.getIndexSize(), light.getIndices(), GL_STATIC_DRAW);

	glGenVertexArrays(1, &lightVAO);
	glBindVertexArray(lightVAO);

	// Bind the VBO to the buffer and set up the attributes
	glBindBuffer(GL_ARRAY_BUFFER, lightVBO);
	int lightStride = light.getInterleavedStride();
	glVertexAttribPointer(0, 3, GL_FLOAT, false, lightStride, (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, false, lightStride, (void*)(sizeof(float) * 3));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, false, lightStride, (void*)(sizeof(float) * 6));
	glEnableVertexAttribArray(2);

	//Bind the IBO to the VAO for rendering
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, lightIBO);


	////// Configure Floor VAO and VBO //////
	unsigned int floorVBO, floorVAO;
	glGenVertexArrays(1, &floorVAO);
	glGenBuffers(1, &floorVBO);

	glBindBuffer(GL_ARRAY_BUFFER, floorVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(floorVerts), floorVerts, GL_STATIC_DRAW);

	glBindVertexArray(floorVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure Rug VAO and VBO //////
	unsigned int rugVBO, rugVAO;
	glGenVertexArrays(1, &rugVAO);
	glGenBuffers(1, &rugVBO);

	glBindBuffer(GL_ARRAY_BUFFER, rugVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(floorVerts), floorVerts, GL_STATIC_DRAW); // Using same vertices as the floor

	glBindVertexArray(rugVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure Ceiling VAO and VBO //////
	unsigned int ceilingVBO, ceilingVAO;
	glGenVertexArrays(1, &ceilingVAO);
	glGenBuffers(1, &ceilingVBO);
	glBindVertexArray(ceilingVAO);

	glBindBuffer(GL_ARRAY_BUFFER, ceilingVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(ceilingVerts), ceilingVerts, GL_STATIC_DRAW);

	glBindVertexArray(ceilingVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure Walls VAO and VBO //////
	unsigned int wallsVBO, wallsVAO;
	glGenVertexArrays(1, &wallsVAO);
	glGenBuffers(1, &wallsVBO);

	glBindBuffer(GL_ARRAY_BUFFER, wallsVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(wallsVerts), wallsVerts, GL_STATIC_DRAW);

	glBindVertexArray(wallsVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure Window VAO and VBO //////
	unsigned int windowVBO, windowVAO;
	glGenVertexArrays(1, &windowVAO);
	glGenBuffers(1, &windowVBO);

	glBindBuffer(GL_ARRAY_BUFFER, windowVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(windowVerts), windowVerts, GL_STATIC_DRAW);

	glBindVertexArray(windowVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure Table Top VAO and VBO //////
	unsigned int tableTopVBO, tableTopVAO;
	glGenVertexArrays(1, &tableTopVAO);
	glGenBuffers(1, &tableTopVBO);

	glBindBuffer(GL_ARRAY_BUFFER, tableTopVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(tableTopVerts), tableTopVerts, GL_STATIC_DRAW);

	glBindVertexArray(tableTopVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure Table Legs VAO and VBO //////
	unsigned int tableLegsVBO, tableLegsVAO;
	glGenVertexArrays(1, &tableLegsVAO);
	glGenBuffers(1, &tableLegsVBO);

	glBindBuffer(GL_ARRAY_BUFFER, tableLegsVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(tableLegsVerts), tableLegsVerts, GL_STATIC_DRAW);

	glBindVertexArray(tableLegsVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure Drawer Border VAO and VBO //////
	unsigned int drawerBorderVBO, drawerBorderVAO;
	glGenVertexArrays(1, &drawerBorderVAO);
	glGenBuffers(1, &drawerBorderVBO);

	glBindBuffer(GL_ARRAY_BUFFER, drawerBorderVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(drawerBorderVerts), drawerBorderVerts, GL_STATIC_DRAW);

	glBindVertexArray(drawerBorderVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure Drawers VAO and VBO //////
	unsigned int drawersVBO, drawersVAO;
	glGenVertexArrays(1, &drawersVAO);
	glGenBuffers(1, &drawersVBO);

	glBindBuffer(GL_ARRAY_BUFFER, drawersVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(drawersVerts), drawersVerts, GL_STATIC_DRAW);

	glBindVertexArray(drawersVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	
	////// Configure Drawer Handles VAO and VBO //////
	unsigned int drawerHandlesVBO, drawerHandlesVAO;
	glGenVertexArrays(1, &drawerHandlesVAO);
	glGenBuffers(1, &drawerHandlesVBO);

	glBindBuffer(GL_ARRAY_BUFFER, drawerHandlesVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(drawerHandlesVerts), drawerHandlesVerts, GL_STATIC_DRAW);

	glBindVertexArray(drawerHandlesVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure the Tall Plant Pot VAO, VBO, and IBO //////
	Cylinder tallPlantPot(0.5, 0.5, 1.5, 20, 10, true); // Base Radius, Top Radius, Height, Sectors, Stacks, Smooth Shading bool

	unsigned int tallPlantPotVBO, tallPlantPotVAO, tallPlantPotIBO;
	glGenBuffers(1, &tallPlantPotVBO);
	glBindBuffer(GL_ARRAY_BUFFER, tallPlantPotVBO);
	glBufferData(GL_ARRAY_BUFFER, tallPlantPot.getInterleavedVertexSize(), tallPlantPot.getInterleavedVertices(), GL_STATIC_DRAW);

	glGenBuffers(1, &tallPlantPotIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, tallPlantPotIBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, tallPlantPot.getIndexSize(), tallPlantPot.getIndices(), GL_STATIC_DRAW);

	glGenVertexArrays(1, &tallPlantPotVAO);
	glBindVertexArray(tallPlantPotVAO);

	// Bind the VBO to the buffer and set up the attributes
	glBindBuffer(GL_ARRAY_BUFFER, tallPlantPotVBO);
	int tallPlantPotStride = tallPlantPot.getInterleavedStride();
	glVertexAttribPointer(0, 3, GL_FLOAT, false, tallPlantPotStride, (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, false, tallPlantPotStride, (void*)(sizeof(float) * 3));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, false, tallPlantPotStride, (void*)(sizeof(float) * 6));
	glEnableVertexAttribArray(2);

	//Bind the IBO to the VAO for rendering
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, tallPlantPotIBO);


	////// Configure Tall Plant VAO and VBO //////
	unsigned int tallPlantVBO, tallPlantVAO;
	glGenVertexArrays(1, &tallPlantVAO);
	glGenBuffers(1, &tallPlantVBO);

	glBindBuffer(GL_ARRAY_BUFFER, tallPlantVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(tallPlantVerts), tallPlantVerts, GL_STATIC_DRAW);

	glBindVertexArray(tallPlantVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure the Short Plant Pot VAO, VBO, and IBO //////
	Cylinder shortPlantPot(0.5, 0.5, 1, 20, 10, true); // Base Radius, Top Radius, Height, Sectors, Stacks, Smooth Shading bool

	unsigned int shortPlantPotVBO, shortPlantPotVAO, shortPlantPotIBO;
	glGenBuffers(1, &shortPlantPotVBO);
	glBindBuffer(GL_ARRAY_BUFFER, shortPlantPotVBO);
	glBufferData(GL_ARRAY_BUFFER, shortPlantPot.getInterleavedVertexSize(), shortPlantPot.getInterleavedVertices(), GL_STATIC_DRAW);

	glGenBuffers(1, &shortPlantPotIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shortPlantPotIBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, shortPlantPot.getIndexSize(), shortPlantPot.getIndices(), GL_STATIC_DRAW);

	glGenVertexArrays(1, &shortPlantPotVAO);
	glBindVertexArray(shortPlantPotVAO);

	// Bind the VBO to the buffer and set up the attributes
	glBindBuffer(GL_ARRAY_BUFFER, shortPlantPotVBO);
	int shortPlantPotStride = shortPlantPot.getInterleavedStride();
	glVertexAttribPointer(0, 3, GL_FLOAT, false, shortPlantPotStride, (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, false, shortPlantPotStride, (void*)(sizeof(float) * 3));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, false, shortPlantPotStride, (void*)(sizeof(float) * 6));
	glEnableVertexAttribArray(2);

	//Bind the IBO to the VAO for rendering
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shortPlantPotIBO);


	////// Configure Short Plant VAO and VBO //////
	unsigned int shortPlantVBO, shortPlantVAO;
	glGenVertexArrays(1, &shortPlantVAO);
	glGenBuffers(1, &shortPlantVBO);

	glBindBuffer(GL_ARRAY_BUFFER, shortPlantVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(shortPlantVerts), shortPlantVerts, GL_STATIC_DRAW);

	glBindVertexArray(shortPlantVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure the Pumpkin Stem VAO, VBO, and IBO //////
	Cylinder pumpkinStem(0.1, 0.4, 0.6, 8, 10, false);

	unsigned int pumpkinStemVBO, pumpkinStemVAO, pumpkinStemIBO;

	glGenBuffers(1, &pumpkinStemVBO);
	glBindBuffer(GL_ARRAY_BUFFER, pumpkinStemVBO);
	glBufferData(GL_ARRAY_BUFFER, pumpkinStem.getInterleavedVertexSize(), pumpkinStem.getInterleavedVertices(), GL_STATIC_DRAW);

	glGenBuffers(1, &pumpkinStemIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pumpkinStemIBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, pumpkinStem.getIndexSize(), pumpkinStem.getIndices(), GL_STATIC_DRAW);

	glGenVertexArrays(1, &pumpkinStemVAO);
	glBindVertexArray(pumpkinStemVAO);

	// Bind the VBO to the buffer and set up the attributes
	glBindBuffer(GL_ARRAY_BUFFER, pumpkinStemVBO);
	int pumpkinStemStride = pumpkinStem.getInterleavedStride();
	glVertexAttribPointer(0, 3, GL_FLOAT, false, pumpkinStemStride, (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, false, pumpkinStemStride, (void*)(sizeof(float) * 3));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, false, pumpkinStemStride, (void*)(sizeof(float) * 6));
	glEnableVertexAttribArray(2);

	//Bind the IBO to the VAO for rendering
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pumpkinStemIBO);


	////// Configure the Cloth VAO and VBO //////
	unsigned int clothVBO, clothVAO;
	glGenVertexArrays(1, &clothVAO);
	glGenBuffers(1, &clothVBO);

	glBindBuffer(GL_ARRAY_BUFFER, clothVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(clothVerts), clothVerts, GL_STATIC_DRAW);

	glBindVertexArray(clothVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	////// Configure the Pumpkin VAO, VBO, and IBO //////
	Sphere pumpkin(0.2f, 7, 50, false);    // Radius, Sectors, Stacks, Smooth Shading bool

	unsigned int pumpkinVBO, pumpkinVAO, pumpkinIBO;
	glGenBuffers(1, &pumpkinVBO);
	glBindBuffer(GL_ARRAY_BUFFER, pumpkinVBO);
	glBufferData(GL_ARRAY_BUFFER, pumpkin.getInterleavedVertexSize(), pumpkin.getInterleavedVertices(), GL_STATIC_DRAW);

	glGenBuffers(1, &pumpkinIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pumpkinIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pumpkinIBO); glBufferData(GL_ELEMENT_ARRAY_BUFFER, pumpkin.getIndexSize(), pumpkin.getIndices(), GL_STATIC_DRAW);

	glGenVertexArrays(1, &pumpkinVAO);
	glBindVertexArray(pumpkinVAO);

	// Bind the VBO to the buffer and set up the attributes
	glBindBuffer(GL_ARRAY_BUFFER, pumpkinVBO);
	int pumpkinStride = pumpkin.getInterleavedStride(); 
	glVertexAttribPointer(0, 3, GL_FLOAT, false, pumpkinStride, (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, false, pumpkinStride, (void*)(sizeof(float) * 3));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, false, pumpkinStride, (void*)(sizeof(float) * 6));
	glEnableVertexAttribArray(2);

	//Bind the IBO to the VAO for rendering
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pumpkinIBO);

	// load textures
	// ------------------------------------------------
	unsigned int texture1 = loadTexture("textures/Wood_Floor.jpg");
	unsigned int texture2 = loadTexture("textures/Ceiling.jpg");
	unsigned int texture3 = loadTexture("textures/Walls.jpg");
	unsigned int texture4 = loadTexture("textures/Rustic.jpg");
	unsigned int texture5 = loadTexture("textures/Metal.jpg");
	unsigned int texture6 = loadTexture("textures/Pumpkin.jpg");
	unsigned int texture7 = loadTexture("textures/Cloth.jpg");
	unsigned int texture8 = loadTexture("textures/PumpkinStem.jpg");
	unsigned int texture9 = loadTexture("textures/PlantPot.jpg");
	unsigned int texture10 = loadTexture("textures/Plant.jpg");
	unsigned int texture11 = loadTexture("textures/Window.jpg");
	unsigned int texture12 = loadTexture("textures/Rug.jpg");

	// shader configuration
	// --------------------
	lightingShader.use();
	lightingShader.setInt("texture1", 0);
	lightingShader.setInt("texture2", 0);
	lightingShader.setInt("texture3", 0);
	lightingShader.setInt("texture4", 0);
	lightingShader.setInt("texture5", 0);
	lightingShader.setInt("texture6", 0);
	lightingShader.setInt("texture7", 0);
	lightingShader.setInt("texture8", 0);
	lightingShader.setInt("texture9", 0);
	lightingShader.setInt("texture10", 0);
	lightingShader.setInt("texture11", 0);
	lightingShader.setInt("texture12", 0);

	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{	
		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		// -----
		processInput(window);
		switchPerspective(); // Call to trigger projection when window is openned

		// render
		// ------
		glClearColor(0.6f, 0.7f, 1.0f, 0.0f); // Light-Sky Blue
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


		// be sure to activate shader when setting uniforms/drawing objects
		lightingShader.use();
		lightingShader.setVec3("viewPos", camera.Position);
		lightingShader.setFloat("material.shininess", 32.0f);

		/*
		   Here we set all the uniforms for the 5/6 types of lights we have. We have to set them manually and index
		   the proper PointLight struct in the array to set each uniform variable. This can be done more code-friendly
		   by defining light types as classes and set their values in there, or by using a more efficient uniform approach
		   by using 'Uniform buffer objects', but that is something we'll discuss in the 'Advanced GLSL' tutorial.
		*/
		// directional light
		lightingShader.setVec3("dirLight.direction", -0.2f, -1.0f, -0.3f);
		lightingShader.setVec3("dirLight.ambient", 0.05f, 0.05f, 0.05f);
		lightingShader.setVec3("dirLight.diffuse", 0.4f, 0.4f, 0.4f);
		lightingShader.setVec3("dirLight.specular", 0.5f, 0.5f, 0.5f);
		// point light 1
		lightingShader.setVec3("pointLights[0].position", pointLightPositions[0]);
		lightingShader.setVec3("pointLights[0].ambient", pointLightColors[0].x * 0.4, pointLightColors[0].y * 0.4, pointLightColors[0].z * 0.4); // White Ambient Light - 40%
		lightingShader.setVec3("pointLights[0].diffuse", 0.0f, 0.0f, 0.0f);  
		lightingShader.setVec3("pointLights[0].specular", 0.0f, 0.0f, 0.0f);
		lightingShader.setFloat("pointLights[0].constant", 1.0f);
		lightingShader.setFloat("pointLights[0].linear", 0.09);
		lightingShader.setFloat("pointLights[0].quadratic", 0.032);
		// point light 2
		lightingShader.setVec3("pointLights[1].position", pointLightPositions[1]);
		lightingShader.setVec3("pointLights[1].ambient", pointLightColors[1].x * 0.1, pointLightColors[1].y * 0.1, pointLightColors[1].z * 0.1);
		lightingShader.setVec3("pointLights[1].diffuse", pointLightColors[1].x * 1.0, pointLightColors[1].y * 1.0, pointLightColors[1].z * 1.0);  // Gold Light - Ambient 10%, Diffuse 100%, Specular 1000%
		lightingShader.setVec3("pointLights[1].specular", pointLightColors[1].x * 1.0, pointLightColors[1].y * 1.0, pointLightColors[1].z * 1.0);
		lightingShader.setFloat("pointLights[1].constant", 1.0f);
		lightingShader.setFloat("pointLights[1].linear", 0.09);
		lightingShader.setFloat("pointLights[1].quadratic", 0.032);
		// point light 3
		lightingShader.setVec3("pointLights[2].position", pointLightPositions[2]);
		lightingShader.setVec3("pointLights[2].ambient", 0.0f, 0.0f, 0.0f);
		lightingShader.setVec3("pointLights[2].diffuse", 0.0f, 0.0f, 0.0f);
		lightingShader.setVec3("pointLights[2].specular", 0.0f, 0.0f, 0.0f);      // Point light 3 turned off
		lightingShader.setFloat("pointLights[2].constant", 1.0f);
		lightingShader.setFloat("pointLights[2].linear", 0.09);
		lightingShader.setFloat("pointLights[2].quadratic", 0.032);
		// point light 4
		lightingShader.setVec3("pointLights[3].position", pointLightPositions[3]);
		lightingShader.setVec3("pointLights[3].ambient", 0.0f, 0.0f, 0.0f);
		lightingShader.setVec3("pointLights[3].diffuse", 0.0f, 0.0f, 0.0f);
		lightingShader.setVec3("pointLights[3].specular", 0.0f, 0.0f, 0.0f);     // Point light 4 turned off 
		lightingShader.setFloat("pointLights[3].constant", 1.0f);
		lightingShader.setFloat("pointLights[3].linear", 0.09);
		lightingShader.setFloat("pointLights[3].quadratic", 0.032);
		// spotLight
		lightingShader.setVec3("spotLight.position", camera.Position);
		lightingShader.setVec3("spotLight.direction", camera.Front);
		lightingShader.setVec3("spotLight.ambient", 0.0f, 0.0f, 0.0f);
		lightingShader.setVec3("spotLight.diffuse", 0.0f, 0.0f, 0.0f);           // Spotlight turned off
		lightingShader.setVec3("spotLight.specular", 0.0f, 0.0f, 0.0f);
		lightingShader.setFloat("spotLight.constant", 1.0f);
		lightingShader.setFloat("spotLight.linear", 0.09);
		lightingShader.setFloat("spotLight.quadratic", 0.032);
		lightingShader.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
		lightingShader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

		// view/projection transformations
		glm::mat4 view = camera.GetViewMatrix();
		lightingShader.setMat4("projection", _Projection);
		lightingShader.setMat4("view", view);

		// world transformation
		glm::mat4 model = glm::mat4(1.0f);
		lightingShader.setMat4("model", model);

		////// Build the Floor //////

		// Binds WoodFloor texture to floor
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture1);

		glBindVertexArray(floorVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 6);
		}

		////// Build the Rug //////

		// Binds Rug texture to the rug
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture12);

		glBindVertexArray(rugVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(-1.4f, -0.49f, 1.7f));
			model = glm::rotate(model, 45.0f, glm::vec3(0.0, 1.0, 0.0f));
			model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.8f));
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 6);
		}

		////// Build the Ceiling //////
	
		// Binds Ceiling texture to ceiling
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);

		glBindVertexArray(ceilingVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 6);
		}

		////// Build the Walls //////
		
		// Binds Walls texture to the walls
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture3);

		glBindVertexArray(wallsVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 36);
		}

		////// Build the Window //////

		// Binds Window texture to the window
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture11);

		glBindVertexArray(windowVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 324);
		}

		////// Build the Table Top //////
		
		// Binds Rustic texture to table top
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture4);

		glBindVertexArray(tableTopVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 36);
		}

		////// Build the Table Legs //////
		
		// Binds Metal texture to table legs
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture5);

		glBindVertexArray(tableLegsVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 36);
		}

		////// Build the Drawer Border //////

		// Binds Metal texture to drawer border
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture5);

		glBindVertexArray(drawerBorderVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 30);
		}

		////// Build the Drawers //////
	
		// Binds Rustic texture to drawers
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture4);

		glBindVertexArray(drawersVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 90);
		}

		////// Build the Drawer Handles //////

		// Binds Metal texture to drawer handles
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture5);

		glBindVertexArray(drawerHandlesVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 36);
		}


		////// Build the Tall Plant Pots //////

		// Binds PlantPot texture to the cylinders
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture9);

		glBindVertexArray(tallPlantPotVAO);
		for (unsigned int i = 0; i < 2; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, plantPotPositions[i]);
			model = glm::scale(model, glm::vec3(0.15f));
			model = glm::rotate(model, 89.5f, glm::vec3(1.0, 0.0, 0.0f));
			lightingShader.setMat4("model", model);

			glDrawElements(GL_TRIANGLES, tallPlantPot.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
		} 

		////// Build the Tall Plants //////
	
		// Binds Plant texture to leaves
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture10);

		glBindVertexArray(tallPlantVAO);
		for (unsigned int i = 0; i < 2; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, plantPositions[i]);
			model = glm::scale(model, glm::vec3(1.5f));
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 48);
		}

		////// Build the Short Plant Pots //////

		// Binds PlantPot texture to the cylinders
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture9);

		glBindVertexArray(shortPlantPotVAO);
		for (unsigned int i = 2; i < 4; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, plantPotPositions[i]);
			model = glm::scale(model, glm::vec3(0.15f));
			model = glm::rotate(model, 89.5f, glm::vec3(1.0, 0.0, 0.0f));
			lightingShader.setMat4("model", model);

			glDrawElements(GL_TRIANGLES, shortPlantPot.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
		}

		////// Build the Short Plants //////

		// Binds Plant texture to leaves
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture10);

		glBindVertexArray(shortPlantVAO);
		for (unsigned int i = 2; i < 4; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, plantPositions[i]);
			model = glm::scale(model, glm::vec3(0.5f));
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 42);
		}

		////// Build the Pumpkin Stem //////

		// Binds PumpkinStem texture to the pumpkin stem
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture8);

		glBindVertexArray(pumpkinStemVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, pumpkinStemPosition[i]);
			model = glm::scale(model, glm::vec3(0.15f));
			model = glm::rotate(model, 89.5f, glm::vec3(1.0, 0.0, 0.0f));
			lightingShader.setMat4("model", model);

			glDrawElements(GL_TRIANGLES, pumpkinStem.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
		}
		
		////// Build the Cloth  //////

		// Binds Cloth texture to the cloth
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture7);

		glBindVertexArray(clothVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			// calculate the model matrix for each object and pass it to shader before drawing
			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, roomPosition[i]);
			lightingShader.setMat4("model", model);

			glDrawArrays(GL_TRIANGLES, 0, 36);
		}

		////// Build the Pumpkin //////

		// Binds Pumpkin texture to pumpkin
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture6);

		glBindVertexArray(pumpkinVAO);
		for (unsigned int i = 0; i < 1; i++)
		{
			model = glm::mat4(1.0f);
			model = glm::translate(model, pumpkinPosition[i]);
			model = glm::rotate(model, 89.5f, glm::vec3(1.0f, 0.0f, 0.0f));
			lightingShader.setMat4("model", model);

			// Draw the pumpkin
			glDrawElements(GL_TRIANGLES, pumpkin.getIndexCount(), GL_UNSIGNED_INT, (void*)0);
		}

		/////// Build the Lights ///////

		lightSphereShader.use();
		lightSphereShader.setMat4("projection", _Projection);
		lightSphereShader.setMat4("view", view);

		glBindVertexArray(lightVAO);
		for (unsigned int i = 0; i < 4; i++)
		{
			model = model = glm::mat4(1.0f);
			model = glm::translate(model, pointLightPositions[i]);
			model = glm::scale(model, glm::vec3(0.2f)); // Make it a smaller sphere
			lightSphereShader.setMat4("model", model);
			// Draw the lights
			glDrawElements(GL_TRIANGLES, light.getIndexCount(), GL_UNSIGNED_INT, (void*)0);

		}

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// optional: de-allocate all resources once they've outlived their purpose:
	// ------------------------------------------------------------------------
	glDeleteVertexArrays(1, &floorVAO);
	glDeleteVertexArrays(1, &rugVAO);
	glDeleteVertexArrays(1, &ceilingVAO);
	glDeleteVertexArrays(1, &wallsVAO);
	glDeleteVertexArrays(1, &windowVAO);
	glDeleteVertexArrays(1, &tableTopVAO);
	glDeleteVertexArrays(1, &tableLegsVAO);
	glDeleteVertexArrays(1, &drawerBorderVAO);
	glDeleteVertexArrays(1, &drawersVAO);
	glDeleteVertexArrays(1, &drawerHandlesVAO);
	glDeleteVertexArrays(1, &shortPlantPotVAO);
	glDeleteVertexArrays(1, &shortPlantVAO);
	glDeleteVertexArrays(1, &tallPlantPotVAO);
	glDeleteVertexArrays(1, &tallPlantVAO);
	glDeleteVertexArrays(1, &pumpkinStemVAO);
	glDeleteVertexArrays(1, &clothVAO);
	glDeleteVertexArrays(1, &pumpkinVAO);
	glDeleteVertexArrays(1, &lightVAO);
	glDeleteBuffers(1, &floorVBO);
	glDeleteBuffers(1, &rugVBO);
	glDeleteBuffers(1, &ceilingVBO);
	glDeleteBuffers(1, &wallsVBO);
	glDeleteBuffers(1, &windowVBO);
	glDeleteBuffers(1, &tableTopVBO);
	glDeleteBuffers(1, &tableLegsVBO);
	glDeleteBuffers(1, &drawerBorderVBO);
	glDeleteBuffers(1, &drawersVBO);
	glDeleteBuffers(1, &drawerHandlesVBO);
	glDeleteBuffers(1, &shortPlantPotVBO);
	glDeleteBuffers(1, &shortPlantVBO);
	glDeleteBuffers(1, &tallPlantPotVBO);
	glDeleteBuffers(1, &tallPlantVBO);
	glDeleteBuffers(1, &pumpkinStemVBO);
	glDeleteBuffers(1, &clothVBO);
	glDeleteBuffers(1, &pumpkinVBO);
	glDeleteBuffers(1, &lightVBO);

	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) // Q = Moves Camera Up
		camera.ProcessKeyboard(UP, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) // E = Move Camera Down
		camera.ProcessKeyboard(DOWN, deltaTime);

	 // P = calls key_callback function to switch between perspective and ortho
	 glfwSetKeyCallback(window, key_callback);
}

// Function to process P key being pressed
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_P && action == GLFW_PRESS)
        if (perspectiveMode) {
            perspectiveMode = false;
            switchPerspective();
        }

        else {
            perspectiveMode = true;
            switchPerspective();
        }
}

// Function called when P Key is hit - Changes projection
void switchPerspective()
{
    // Return the correct perspective
    if (perspectiveMode)
	{
        // Perspective
        _Projection = glm::perspective(glm::radians(camera.Zoom), (GLfloat)SCR_WIDTH / (GLfloat)SCR_HEIGHT, 0.1f, 100.0f);
    }
    
    else if(!perspectiveMode)
    {
        // Ortho
        float scale = 100;
        _Projection = glm::ortho(-((float)SCR_WIDTH / scale), (float)SCR_WIDTH / scale, -((float)SCR_HEIGHT/ scale), (float)SCR_HEIGHT / scale, 0.1f, 100.0f);
    }
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

	lastX = xpos;
	lastY = ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	// Add 0.5/Remove 0.5 depending on direction
    float newMovementSpeed = yoffset > 0 ? camera.MovementSpeed + 0.5 : camera.MovementSpeed - 0.5;
    // Set the movement speed. Check if its attempting to go negative, which reverses the control scheme
    camera.MovementSpeed = newMovementSpeed > 0 ? newMovementSpeed : 0.5;
}

// utility function for loading a 2D texture from file
// ---------------------------------------------------
unsigned int loadTexture(char const* path)
{
	unsigned int textureID;
	glGenTextures(1, &textureID);

	int width, height, nrComponents;
	unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
	if (data)
	{
		GLenum format;
		if (nrComponents == 1)
			format = GL_RED;
		else if (nrComponents == 3)
			format = GL_RGB;
		else if (nrComponents == 4)
			format = GL_RGBA;

		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		stbi_image_free(data);
	}
	else
	{
		std::cout << "Texture failed to load at path: " << path << std::endl;
		stbi_image_free(data);
	}

	return textureID;
}

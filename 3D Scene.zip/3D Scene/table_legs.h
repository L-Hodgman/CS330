#pragma once
#include <glad/glad.h>
#include <vector>

using namespace std; // Standard namespace

class TableLegs
{
public:
	static vector<GLfloat>* drawTableLegs();
};

